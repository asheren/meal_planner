// Datepicker initialization for recipes
$(function() {
  $('.datepicker').datepicker({
    format: 'yyyy-mm-dd'
  });
});
